package com.jdacode.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.jdacode.dao.BankMemberDao;
import com.jdacode.entity.BankMember;

//Include business logic in this class
@Service 
@Qualifier("fileSysData")
public class BankMemberService {

	@Autowired
	private BankMemberDao bankMemberDao;
	
	public Collection<BankMember> getAllBankMembers() {
		return this.bankMemberDao.getAllBankMembers();
	}
	
	public BankMember getBankMemberById(int id) {
		return this.bankMemberDao.getBankMemberById(id);
	}

	public void deleteBankMemberById(int id) {
		this.bankMemberDao.deleteBankMemberById(id);
	}
	
	public void updateBankMember(BankMember bankMember) {
		this.bankMemberDao.updateBankMemberById(bankMember);
	}

	public void addBankMember(BankMember bankMember) {
		this.bankMemberDao.addBankMember(bankMember);
	}
}
