package com.jdacode.dao;

import java.util.Collection;

import com.jdacode.entity.BankMember;

public interface BankMemberDao {

	Collection<BankMember> getAllBankMembers();

	BankMember getBankMemberById(int id);

	void deleteBankMemberById(int id);

	void updateBankMemberById(BankMember bankMember);

	void addBankMember(BankMember bankMember);
	
}