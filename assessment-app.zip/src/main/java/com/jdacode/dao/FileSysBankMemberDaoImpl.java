package com.jdacode.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.jdacode.entity.BankMember;

@Repository
@Qualifier("fileSysData")
public class FileSysBankMemberDaoImpl implements BankMemberDao {

	private static Map<Integer, BankMember> members = new HashMap<Integer, BankMember>();
	
	/* (non-Javadoc)
	 * @see com.jdacode.dao.BankMemberDao#getAllBankMembers()
	 */
	@Override
	public Collection<BankMember> getAllBankMembers() {
		return members.values();
	}
	
	/* (non-Javadoc)
	 * @see com.jdacode.dao.BankMemberDao#getBankMemberById(int)
	 */
	@Override
	public BankMember getBankMemberById(int id) {
		return members.get(id) ;
	}

	/* (non-Javadoc)
	 * @see com.jdacode.dao.BankMemberDao#deleteBankMemberById(int)
	 */
	@Override
	public void deleteBankMemberById(int id) {
		members.remove(id);
	}
	
	/* (non-Javadoc)
	 * @see com.jdacode.dao.BankMemberDao#updateBankMemberById(com.jdacode.entity.BankMember)
	 */
	@Override
	public void updateBankMemberById(BankMember bankMember) {
		members.put(bankMember.getId(), bankMember);
	}

	/* (non-Javadoc)
	 * @see com.jdacode.dao.BankMemberDao#addBankMember(com.jdacode.entity.BankMember)
	 */
	@Override
	public void addBankMember(BankMember bankMember) {
		members.put(bankMember.getId(), bankMember);
	}
}
