package com.jdacode.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jdacode.entity.BankMember;
import com.jdacode.service.BankMemberService;

@RestController
@RequestMapping("/bankMembers")
public class BankMemberController {
	
	@Autowired //spring finds bean of bankMemberService and injects it here
	private BankMemberService bankMemberService;
	
	//List all of the members of the bank
	@RequestMapping(method = RequestMethod.GET)
	public Collection<BankMember> getAllBankMembers() {
		return bankMemberService.getAllBankMembers();
	}
	
	//Display a member of the bank who has the specified id
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public BankMember getBankMemberById(@PathVariable("id") int id) {
		return bankMemberService.getBankMemberById(id);
	}
	
	//Delete a member of the bank who has the specified id
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void deleteBankMemberById(@PathVariable("id") int id) {
		bankMemberService.deleteBankMemberById(id);
	}
	
	//Change a member of the bank who has the same id as the specified member
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void updateBankMemberById(@RequestBody BankMember bankMember) {
		bankMemberService.updateBankMember(bankMember);
	}
	
	//Add the specified member to the collection of bank members
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void addBankMember(@RequestBody BankMember bankMember) {
		bankMemberService.addBankMember(bankMember);
	}
}
