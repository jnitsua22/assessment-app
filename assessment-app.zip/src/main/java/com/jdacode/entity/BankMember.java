package com.jdacode.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.annotation.Id;

public class BankMember {
	
	private int		id;
	private String 	firstName, lastName;
	private int		balance;	//balance is total bank balance
	
	
	//Constructors
	public BankMember() {
	}
	public BankMember(int id, String firstName, String lastName, int balance) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.balance = balance;
		this.id = id;
	}


	//Getters and Setters
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	@Id
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	//toString method
	public String toString() {
		return new ToStringBuilder(this).
				append("firstName",firstName).
				append("lastName",lastName).
				append("balance",balance).
				append("id",id).toString();
				
	}
}
