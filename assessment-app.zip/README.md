# assessment-app
A RESTful APL spring-boot application for Apex Systems
